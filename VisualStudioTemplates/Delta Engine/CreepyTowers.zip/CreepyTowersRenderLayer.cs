namespace $safeprojectname$
{
	public enum CreepyTowersRenderLayer
	{
		Model = 1,
		Towers = 4,
		Creeps = 8,
		Interface = 12,
		Dialogues = 16
	}
}